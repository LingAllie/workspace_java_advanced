package com.vti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex2Ex3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
